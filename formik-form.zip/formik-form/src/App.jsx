import React from "react";
import SignupForm from "./components/SignupForm";

const App = () => {
  return (
    <div>
      <SignupForm />
    </div>
  );
};

export default App;
